# DigitalPot_MCP41010
  Library and example to control a Microchip MCP41010  digital potentiometer with a MSP-EXP430F5529LP over SPI.
  
  See wiki for additional information.
